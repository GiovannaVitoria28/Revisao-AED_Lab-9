# questão 01
numeros = []
while True:
    valor = int(input("Digite um número inteiro (digite -1 para terminar): "))
    if valor == -1:
        break
    numeros.append(valor)

if len(numeros) < 4:
    print("Por favor, digite pelo menos 4 números!")
else:
    print("Lista original:", numeros)
    print("3 primeiros elementos:", numeros[:3])
    print("2 últimos elementos:", numeros[-2:])
    print("Lista invertida:", numeros[::-1])
    print("Índices pares:", numeros[::2])
    print("Índices ímpares:", numeros[1::2])

# questão 02
urls = ["www.google.com", "www.gmail.com", "www.github.com", "www.reddit.com", "www.yahoo.com"]
dominios = []
for endereco in urls:
    sem_www = endereco[4:]
    nome = sem_www[:-4]
    dominios.append(nome)
print("URLs:", urls)
print("Domínios:", dominios)

# questão 03
from random import randint

lista_aleatoria = []
for _ in range(10):
    num = randint(-100, 100)
    lista_aleatoria.append(num)

lista_ordenada = sorted(lista_aleatoria)
maior_valor = max(lista_aleatoria)
menor_valor = min(lista_aleatoria)
indice_maior = lista_aleatoria.index(maior_valor)
indice_menor = lista_aleatoria.index(menor_valor)
soma = sum(lista_aleatoria)
media = soma / len(lista_aleatoria)

print("Lista ordenada:", lista_ordenada)
print("Lista original:", lista_aleatoria)
print("Índice do maior valor:", indice_maior)
print("Índice do menor valor:", indice_menor)
print("Soma dos valores:", soma)
print("Média dos valores:", media)

# questão 04
qtd1 = int(input("Digite a quantidade de elementos da lista 1: "))
lista1 = []
for i in range(qtd1):
    n = int(input(f"Digite o {i+1}º elemento da lista 1: "))
    lista1.append(n)

qtd2 = int(input("Digite a quantidade de elementos da lista 2: "))
lista2 = []
for i in range(qtd2):
    n = int(input(f"Digite o {i+1}º elemento da lista 2: "))
    lista2.append(n)

intercalada = []
tamanho_menor = min(len(lista1), len(lista2))
for i in range(tamanho_menor):
    intercalada.append(lista1[i])
    intercalada.append(lista2[i])

if len(lista1) > len(lista2):
    intercalada.extend(lista1[tamanho_menor:])
else:
    intercalada.extend(lista2[tamanho_menor:])

print("Lista intercalada:", intercalada)

# questão 05
from random import randint

lista1 = []
lista2 = []
for _ in range(20):
    lista1.append(randint(0, 50))
    lista2.append(randint(0, 50))

interseccao = []
for valor in lista1:
    if valor in lista2 and valor not in interseccao:
        interseccao.append(valor)

interseccao.sort()

print("lista1 -", lista1)
print("lista2 -", lista2)
print("Interseção -", interseccao)

# questão 06
from random import randint

lista_grande = []
for _ in range(20):
    lista_grande.append(randint(0, 100))

tamanho_sub = int(input("Tamanho para divisão: "))

subs = []
for i in range(0, len(lista_grande), tamanho_sub):
    pedaco = lista_grande[i:i+tamanho_sub]
    subs.append(pedaco)

print("Lista original:")
print(lista_grande)
print("Sublistas:")
print(subs)

# questão 07
n = int(input("Digite n: "))
matriz = []
for linha in range(n):
    linha_dados = [linha] * n
    matriz.append(linha_dados)

print("Resultado:")
for linha in matriz:
    print(linha)
    