#Questão 01
primeiro = input("Digie seu primeiro nome: ")
sobrenome = input("Digite seu sobrenome: ")
nome_completo = primeiro + " " + sobrenome
print(f"Bem-vinda, {nome_completo}!")

#Questão 02
frase = input("Digite a frase: ")
quantidade_espacos = frase.count(" ")
print(f"Espaços em branco: {quantidade_espacos}")

# questão 03
nome = input("Digite seu nome: ")
for i in range(len(nome)):
    print(nome[:i+1])

# questão 04
numero = input("Digite o número: ")
if len(numero) == 8:
    numero = "9" + numero
if len(numero) == 9:
    parte1 = numero[:5]
    parte2 = numero[5:]
    numero_formatado = parte1 + "-" + parte2
    print(f"Número completo: {numero_formatado}")
else:
    print("Número com quantidade de dígitos inválida")

# questão 05
frase = input("Digite uma frase: ")
vogais = "aeiou"
indices = []
contador = 0
for indice, letra in enumerate(frase):
    if letra in vogais:
        indices.append(str(indice))
        contador = contador + 1
print("Índices das vogais:", ", ".join(indices) + ",")
print(f"Total: {contador} vogais")
