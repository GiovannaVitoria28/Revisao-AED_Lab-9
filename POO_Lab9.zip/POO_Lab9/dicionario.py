# Q1 - Contagem de caracteres
def contagem_caracteres(texto):
    contagem = {}
    for caractere in texto:
        if caractere in contagem:
            contagem[caractere] = contagem[caractere] + 1
        else:
            contagem[caractere] = 1
    return contagem

# Exemplo para testar
frase = "python programming"
resultado = contagem_caracteres(frase)
print(resultado)

# Q2 - Contar palavras
def contar_palavras_arquivo():
    with open("estomago.txt", "r", encoding="utf-8") as arquivo:
        texto = arquivo.read()
    
    palavras = texto.lower().split()
    
    contagem = {}
    for p in palavras:
        if p in contagem:
            contagem[p] = contagem[p] + 1
        else:
            contagem[p] = 1
    
    ordenado = dict(sorted(contagem.items(), key=lambda item: item[1], reverse=True))
    return ordenado

resultado = contar_palavras_arquivo()
print(resultado)

# Q3 - Mesclar dicionários
def mesclar_dicionarios(dic1, dic2):
    resultado = dic1.copy()
    
    for chave, valor in dic2.items():
        if chave in resultado:
            if valor > resultado[chave]:
                resultado[chave] = valor
        else:
            resultado[chave] = valor
    return resultado

# Exemplo para testar
dicionario1 = {'a': 1, 'b': 2, 'c': 3}
dicionario2 = {'b': 4, 'd': 5}

resultado = mesclar_dicionarios(dicionario1, dicionario2)
print(resultado)

# Q4 - Inverter dicionário (chave vira valor, valor vira chave)
def inverter_dicionario(dicionario):
    novo = {}
    
    for chave, valor in dicionario.items():
        novo[valor] = chave
    
    return novo

# Exemplo para testar
original = {'nome': 'Maria', 'idade': 20, 'cidade': 'Belo Horizonte'}
resultado = inverter_dicionario(original)
print("Original:", original)
print("Invertido:", resultado)

# Q5 - Filtrar dicionário: manter só valores maiores que o limite
def filtrar_por_valor(dicionario, limite):
    resultado = {}
    
    for chave, valor in dicionario.items():
        if valor > limite:
            resultado[chave] = valor
    
    return resultado

# Exemplo para testar
notas = {'Ana': 8, 'Bruno': 5, 'Carla': 9, 'Daniel': 6}
acima_media = filtrar_por_valor(notas, 7)
print(acima_media)



